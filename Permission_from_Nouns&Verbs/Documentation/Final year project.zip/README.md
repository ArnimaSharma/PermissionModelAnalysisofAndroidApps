(CC BY-NC-SA 3.0)


This second major version of this template was made by Vel. The thesis style was originally created by Steve R. Gunn and modified into a template by Ramesh babu B.

Downloaded from latextemplates.com

Modified for MNIT B.Tech Thesis requirements.
